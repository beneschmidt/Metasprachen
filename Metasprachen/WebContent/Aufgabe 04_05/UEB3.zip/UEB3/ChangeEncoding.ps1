$FolderPath = "C:\Users\Fuss\Desktop\UEB3\"
$PathOrigin = $FolderPath + "UnicodeUTF8.xml"
$PathDestination16 = $FolderPath + "UnicodeUTF16.xml"
$PathDestination32 = $FolderPath + "UnicodeUTF32.xml"
$Header16 = '<?xml version="1.0" encoding="utf-16"?>'
$Header32 = '<?xml version="1.0" encoding="utf-32"?>'

$Content = gc $PathOrigin

if (!(test-path $PathDestination16)) {
	New-Item $PathDestination16 -type File -Force
}

if (!(test-path $PathDestination32)) {
	New-Item $PathDestination32 -type File -Force
}

$NotFirstLine = $false
$Content | % {
	if ($NotFirstLine) {
		$NewContent += $_
	} else {
		$NotFirstLine = $true
	}
}

$Header16 | Out-File $PathDestination16 -Encoding unicode
$NewContent | Out-File $PathDestination16 -Encoding unicode -Append
$Header32 | Out-File $PathDestination32 -Encoding utf32
$NewContent | Out-File $PathDestination32 -Encoding utf32 -Append